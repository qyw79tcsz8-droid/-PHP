<?php

declare(strict_types=1);

require __DIR__ . '/Student.php';

/**
 * Вспомогательная функция: падение строки до заданной ширины
 * с учётом кириллицы (обычный str_pad считает байты, а не символы).
 */
function pad(string $text, int $width, string $align = 'left'): string
{
    $fill = $width - mb_strlen($text);

    if ($fill <= 0) {
        return $text;
    }

    return match ($align) {
        'right' => str_repeat(' ', $fill) . $text,
        default => $text . str_repeat(' ', $fill),
    };
}

echo '=== Учёт студентов ===' . PHP_EOL . PHP_EOL;

// Пункт 5: создаём 4 студентов, заполняем оценки и почту (у одного почты нет)
$students = [
    new Student(101, 'Танаева', 'Дарья', 3),
    new Student(102, 'Иванова', 'Елена', 1),
    new Student(103, 'Петров', 'Максим', 2),
    new Student(104, 'Сидорова', 'Ольга', 4),
];

$students[0]->email = 'darya.tanaeva@example.com';
$students[1]->email = 'elena.ivanova@example.com';
$students[2]->email = 'maxim.petrov@example.com';
// $students[3]->email остаётся null — почта не указана

$students[0]->addGrade(5);
$students[0]->addGrade(5);
$students[0]->addGrade(4);
$students[0]->addGrade(5);

$students[1]->addGrade(4);
$students[1]->addGrade(3);
$students[1]->addGrade(4);
$students[1]->addGrade(5);

$students[2]->addGrade(3);
$students[2]->addGrade(4);
$students[2]->addGrade(4);
$students[2]->addGrade(3);

$students[3]->addGrade(5);
$students[3]->addGrade(4);
$students[3]->addGrade(4);
$students[3]->addGrade(4);

// Пункт 6: таблица студентов
echo pad('Билет', 5) . ' | ' . pad('ФИО', 20) . ' | ' . pad('Курс', 4) . ' | '
    . pad('Почта', 27) . ' | ' . pad('Ср. балл', 8) . PHP_EOL;
echo str_repeat('-', 5 + 3 + 20 + 3 + 4 + 3 + 27 + 3 + 8) . PHP_EOL;

foreach ($students as $student) {
    $email = $student->email ?? 'не указана';
    $avg   = number_format($student->getAverage(), 2, ',', '');

    echo pad((string) $student->id, 5) . ' | '
        . pad($student->getFullName(), 20) . ' | '
        . pad((string) $student->course, 4) . ' | '
        . pad($email, 27) . ' | '
        . pad($avg, 8, 'right') . PHP_EOL;
}

echo PHP_EOL . 'Всего студентов создано: ' . Student::$totalStudents . PHP_EOL;
echo 'Учебное заведение (Student::$university): ' . Student::getUniversity() . PHP_EOL;

// Пункт 7: эксперименты
echo PHP_EOL . '=== Эксперименты (пункт 7) ===' . PHP_EOL;

// 1) Попытка изменить readonly-свойство $id после создания объекта
echo '1) Пытаемся изменить $id: ' . PHP_EOL . '   ';
try {
    $students[0]->id = 999;
} catch (Error $e) {
    echo $e->getMessage() . PHP_EOL;
}

// 2) Присваивание строки в типизированное свойство $course при strict_types=1
echo '2) Пытаемся записать в $course строку «третий»:' . PHP_EOL . '   ';
try {
    $students[0]->course = 'третий';
} catch (TypeError $e) {
    echo $e->getMessage() . PHP_EOL;
}

// 3) Попытка создать студента с курсом 7 — вне MIN_COURSE..MAX_COURSE
echo '3) Пытаемся создать студента с курсом 7:' . PHP_EOL . '   ';
try {
    new Student(105, 'Смирнова', 'Алина', 7);
} catch (InvalidArgumentException $e) {
    echo $e->getMessage() . PHP_EOL;
}

// 4) Изменение статического свойства $university — видно ли всем объектам?
echo '4) Меняем Student::$university и проверяем у разных объектов:' . PHP_EOL;
Student::$university = 'Техникум информационных технологий';
echo '   $students[0]->getUniversity(): ' . $students[0]->getUniversity() . PHP_EOL;
echo '   $students[3]->getUniversity(): ' . $students[3]->getUniversity() . PHP_EOL;
echo '   Student::$university:          ' . Student::$university . PHP_EOL;
echo '   Вывод: изменение видно у всех объектов, потому что статическое '
    . 'свойство общее для всего класса.' . PHP_EOL;

// 5) var_dump() и get_object_vars() для одного объекта
echo '5) var_dump($students[0]):' . PHP_EOL;
var_dump($students[0]);

echo PHP_EOL . 'get_object_vars($students[0]) — снаружи видны только public-свойства:' . PHP_EOL;
var_dump(get_object_vars($students[0]));

// Дополнительно (на отлично): __set() перехватывает запись несуществующих свойств
echo PHP_EOL . '=== Дополнительно: магический метод __set() ===' . PHP_EOL;
$students[0]->nickname = 'Даша';
$students[0]->group    = 'Ис-381';

echo 'История попыток записи (getHistory()): ' . PHP_EOL . '   ';
var_dump($students[0]->getHistory());

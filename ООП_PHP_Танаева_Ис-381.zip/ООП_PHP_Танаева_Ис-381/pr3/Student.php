<?php

declare(strict_types=1);

/**
 * Студент учебного заведения.
 *
 * Демонстрирует: продвигаемые свойства конструктора, readonly-свойство,
 * nullable-свойства, константы класса, статические свойства и метод,
 * магический метод __set().
 */
class Student
{
    public const MIN_COURSE = 1;
    public const MAX_COURSE = 4;

    /** Статические свойства — общие для всех объектов класса */
    public static int $totalStudents = 0;
    public static string $university = 'Колледж информационных технологий';

    /** Продвигаемые свойства конструктора (PHP 8.0+) */
    public function __construct(
        public readonly int $id,       // номер студенческого билета — задаётся один раз
        public string $lastName,
        public string $firstName,
        public int $course,
    ) {
        // Пункт 3: проверяем, что курс в допустимых пределах
        if ($course < self::MIN_COURSE || $course > self::MAX_COURSE) {
            throw new InvalidArgumentException(
                'Курс должен быть в пределах от ' . self::MIN_COURSE
                . ' до ' . self::MAX_COURSE . ', получено: ' . $course
            );
        }

        self::$totalStudents++; // считаем всех созданных студентов
    }

    // Обычные свойства со значениями по умолчанию
    public ?string $email = null;   // почта может быть не указана (nullable)
    public array $grades = [];      // список оценок
    public bool $isActive = true;   // учится ли студент сейчас

    /** Попытки записать несуществующее свойство сохраняются сюда (дополнительно) */
    private array $history = [];

    /**
     * Магический метод __set(): срабатывает при записи в несуществующее
     * (или недоступное) свойство. Динамическое свойство не создаём.
     */
    public function __set(string $name, mixed $value): void
    {
        $this->history[] = $name;
        echo "Предупреждение: свойство «{$name}» у студента не существует, "
            . "запись сохранена в историю (значение: " . var_export($value, true) . ")" . PHP_EOL;
    }

    /** Возвращает список имён несуществующих свойств, которые пытались записать */
    public function getHistory(): array
    {
        return $this->history;
    }

    public function addGrade(int $grade): void
    {
        $this->grades[] = $grade;
    }

    /** Средний балл по всем оценкам */
    public function getAverage(): float
    {
        if ($this->grades === []) {
            return 0.0;
        }

        return array_sum($this->grades) / count($this->grades);
    }

    public function getFullName(): string
    {
        return "{$this->lastName} {$this->firstName}";
    }

    /** Статический метод — читает статическое свойство класса */
    public static function getUniversity(): string
    {
        return self::$university;
    }
}

<?php

declare(strict_types=1);

require __DIR__ . '/Book.php';
require __DIR__ . '/Library.php';

/**
 * Вспомогательная функция: правильное окончание «год / года / лет».
 */
function pluralYears(int $n): string
{
    $mod100 = $n % 100;

    if ($mod100 >= 11 && $mod100 <= 14) {
        return "$n лет";
    }

    return match ($n % 10) {
        1       => "$n год",
        2, 3, 4 => "$n года",
        default => "$n лет",
    };
}

echo '=== Домашняя библиотека ===' . PHP_EOL . PHP_EOL;

$library = new Library();

// Пункт 6: создаём не менее 5 объектов Book и добавляем их в библиотеку
$book1 = new Book('Мастер и Маргарита', 'М. Булгаков', 1967, 480);
$book2 = new Book('Преступление и наказание', 'Ф. Достоевский', 1866, 672);
$book3 = new Book('Евгений Онегин', 'А. Пушкин', 1833, 224);
$book4 = new Book('Война и мир', 'Л. Толстой', 1869, 1225);
$book5 = new Book('Анна Каренина', 'Л. Толстой', 1878, 864);

$library->addBook($book1);
$library->addBook($book2);
$library->addBook($book3);
$library->addBook($book4);
$library->addBook($book5);

// Метод printAll() — информация обо всех книгах
echo 'Список книг:' . PHP_EOL;
$library->printAll();

// Метод getAge() — возраст каждой книги
echo PHP_EOL . 'Возраст книг:' . PHP_EOL;
echo '- «Мастер и Маргарита»: ' . pluralYears($book1->getAge()) . PHP_EOL;
echo '- «Преступление и наказание»: ' . pluralYears($book2->getAge()) . PHP_EOL;
echo '- «Евгений Онегин»: ' . pluralYears($book3->getAge()) . PHP_EOL;

// Метод count() — количество книг
echo PHP_EOL . 'Количество книг в библиотеке: ' . $library->count() . PHP_EOL;

// Метод findByAuthor() — поиск по автору
echo PHP_EOL . 'Поиск по автору «Л. Толстой»:' . PHP_EOL;
foreach ($library->findByAuthor('Л. Толстой') as $book) {
    echo '- ' . $book->getInfo() . PHP_EOL;
}

echo PHP_EOL . 'Поиск по автору «а. пушкин» (проверка регистра):' . PHP_EOL;
foreach ($library->findByAuthor('а. пушкин') as $book) {
    echo '- ' . $book->getInfo() . PHP_EOL;
}

echo PHP_EOL . 'Поиск по автору «А. Чехов» (книг нет):' . PHP_EOL;
$chehovBooks = $library->findByAuthor('А. Чехов');
echo $chehovBooks === [] ? '- ничего не найдено' : '- найдены книги';
echo PHP_EOL;

// Дополнительно (на отлично): getOldest() — самая старая книга
$oldest = $library->getOldest();
echo PHP_EOL . 'Самая старая книга: ' . ($oldest?->getInfo() ?? 'null')
    . ' — ' . pluralYears($oldest->getAge()) . PHP_EOL;

// Проверяем getOldest() на пустой библиотеке
$emptyLibrary = new Library();
$oldestInEmpty = $emptyLibrary->getOldest();
echo 'Самая старая книга в пустой библиотеке: '
    . ($oldestInEmpty?->getInfo() ?? 'null (библиотека пуста)') . PHP_EOL;

// Пункт 7: разница между присваиванием и клонированием
echo PHP_EOL . '=== Пункт 7. Присваивание и клонирование ===' . PHP_EOL;

$b1 = new Book('Мастер и Маргарита', 'М. Булгаков', 1967, 480);
$b2 = $b1;          // присваивание: $b2 и $b1 — один и тот же объект
$b3 = clone $b1;    // клонирование: $b3 — независимая копия

$b1->title = 'Мастер и Маргарита (переиздание 2026 г.)'; // меняем название у $b1

echo '$b1 (оригинал): ' . $b1->getInfo() . PHP_EOL;
echo '$b2 = $b1:     ' . $b2->getInfo() . PHP_EOL;
echo '$b3 = clone:   ' . $b3->getInfo() . PHP_EOL;

echo PHP_EOL . 'var_dump($b1 === $b2): ';
var_dump($b1 === $b2); // true — это один и тот же объект
echo 'var_dump($b1 === $b3): ';
var_dump($b1 === $b3); // false — это разные объекты

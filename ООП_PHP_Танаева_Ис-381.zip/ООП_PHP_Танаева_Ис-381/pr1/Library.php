<?php

declare(strict_types=1);

/**
 * Домашняя библиотека — хранит список книг и умеет с ними работать.
 */
class Library
{
    private array $books = [];

    /**
     * Добавляет книгу в библиотеку.
     */
    public function addBook(Book $book): void
    {
        $this->books[] = $book;
    }

    /**
     * Возвращает массив книг заданного автора (поиск без учёта регистра).
     */
    public function findByAuthor(string $author): array
    {
        $result = [];

        foreach ($this->books as $book) {
            if (mb_strtolower($book->author) === mb_strtolower($author)) {
                $result[] = $book;
            }
        }

        return $result;
    }

    /**
     * Количество книг в библиотеке.
     */
    public function count(): int
    {
        return count($this->books);
    }

    /**
     * Выводит информацию обо всех книгах.
     */
    public function printAll(): void
    {
        foreach ($this->books as $i => $book) {
            echo ($i + 1) . '. ' . $book->getInfo() . PHP_EOL;
        }
    }

    /**
     * Дополнительно (на отлично): самая старая книга или null, если библиотека пуста.
     */
    public function getOldest(): ?Book
    {
        if ($this->books === []) {
            return null;
        }

        $oldest = $this->books[0];

        foreach ($this->books as $book) {
            if ($book->year < $oldest->year) {
                $oldest = $book;
            }
        }

        return $oldest;
    }
}

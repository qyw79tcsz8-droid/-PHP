<?php

declare(strict_types=1);

/**
 * Книга домашней библиотеки.
 */
class Book
{
    public string $title;   // название
    public string $author;  // автор
    public int $year;       // год издания
    public int $pages;      // количество страниц

    public function __construct(string $title, string $author, int $year, int $pages)
    {
        $this->title = $title;
        $this->author = $author;
        $this->year = $year;
        $this->pages = $pages;
    }

    /**
     * Информация о книге в виде строки.
     * Пример: «Мастер и Маргарита — М. Булгаков, 1967, 480 стр.»
     */
    public function getInfo(): string
    {
        return "{$this->title} — {$this->author}, {$this->year}, {$this->pages} стр.";
    }

    /**
     * Возраст книги в годах (текущий год берём через date('Y')).
     */
    public function getAge(): int
    {
        return (int) date('Y') - $this->year;
    }
}

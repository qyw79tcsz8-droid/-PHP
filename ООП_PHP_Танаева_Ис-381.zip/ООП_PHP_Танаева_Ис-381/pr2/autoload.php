<?php

declare(strict_types=1);

/**
 * Собственный автозагрузчик (вариант без Composer).
 *
 * Правило PSR-4: класс Shop\Models\Product лежит в файле
 * src/Models/Product.php, то есть префикс Shop\ соответствует папке src/.
 */
spl_autoload_register(function (string $class): void {
    $prefix  = 'Shop\\';              // ищем только классы нашего пространства имён
    $baseDir = __DIR__ . '/src/';

    if (!str_starts_with($class, $prefix)) {
        return; // не наш класс — пусть его грузит другой загрузчик
    }

    // Shop\Models\Product -> Models\Product -> src/Models/Product.php
    $relative = substr($class, strlen($prefix));
    $file     = $baseDir . str_replace('\\', '/', $relative) . '.php';

    if (is_file($file)) {
        // Отладочный вывод (пункт 4): видно, что класс загружается
        // только в момент первого использования
        echo "Загружен класс: {$class}" . PHP_EOL;

        require $file;
    }
});

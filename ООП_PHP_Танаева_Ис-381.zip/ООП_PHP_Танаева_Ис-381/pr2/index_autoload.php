<?php

declare(strict_types=1);

/**
 * Вариант 1 (пункты 3–5 задания): подключаем СВОЙ автозагрузчик.
 * Этот файл используется для демонстрации отладочного вывода —
 * видно, в каком порядке и в какой момент загружаются классы.
 *
 * Вариант 2 (пункт 6) — основной файл index.php, который работает
 * через composer dump-autoload и vendor/autoload.php.
 */

require __DIR__ . '/autoload.php';

use Shop\Helpers\PriceFormatter;
use Shop\Models\Customer;
use Shop\Models\Product;
use Shop\Services\Cart;

$customer = new Customer('Дарья Танаева', 'darya.tanaeva@example.com');
echo "Покупатель: {$customer->name} <{$customer->email}>" . PHP_EOL . PHP_EOL;

$cart = new Cart($customer);
echo 'Товары в корзине:' . PHP_EOL;

$goods = [
    ['name' => 'Клавиатура Logitech K120', 'price' => 3490.00, 'qty' => 1],
    ['name' => 'Мышь Logitech M185', 'price' => 1890.50, 'qty' => 2],
    ['name' => 'Коврик для мыши синий', 'price' => 590.00, 'qty' => 1],
];

foreach ($goods as $good) {
    $product = new Product($good['name'], $good['price']);
    $cart->add($product, $good['qty']);

    $sum = $product->price * $good['qty'];
    echo "- {$product->name} × {$good['qty']} шт. — " . PriceFormatter::format($sum) . PHP_EOL;
}

echo PHP_EOL . 'Итого: ' . PriceFormatter::format($cart->getTotal()) . PHP_EOL;

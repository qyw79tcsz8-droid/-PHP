<?php

declare(strict_types=1);

/**
 * Пункт 6 задания: проект переведён на Composer.
 * Подключаем автозагрузчик, сгенерированный командой composer dump-autoload.
 * Ни одного require отдельного класса в проекте нет — классы подгружаются сами.
 */

require __DIR__ . '/vendor/autoload.php';

use Shop\Helpers\PriceFormatter;
use Shop\Models\Customer;
use Shop\Models\Product;
use Shop\Services\Cart;

$customer = new Customer('Дарья Танаева', 'darya.tanaeva@example.com');
echo "Покупатель: {$customer->name} <{$customer->email}>" . PHP_EOL . PHP_EOL;

$cart = new Cart($customer);
echo 'Товары в корзине:' . PHP_EOL;

$goods = [
    ['name' => 'Клавиатура Logitech K120', 'price' => 3490.00, 'qty' => 1],
    ['name' => 'Мышь Logitech M185', 'price' => 1890.50, 'qty' => 2],
    ['name' => 'Коврик для мыши синий', 'price' => 590.00, 'qty' => 1],
];

foreach ($goods as $good) {
    $product = new Product($good['name'], $good['price']);
    $cart->add($product, $good['qty']);

    $sum = $product->price * $good['qty'];
    echo "- {$product->name} × {$good['qty']} шт. — " . PriceFormatter::format($sum) . PHP_EOL;
}

echo PHP_EOL . 'Итого: ' . PriceFormatter::format($cart->getTotal()) . PHP_EOL;

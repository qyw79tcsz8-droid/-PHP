<?php

declare(strict_types=1);

namespace Shop\Services;

use Shop\Models\Customer;
use Shop\Models\Product;

/**
 * Корзина покупателя.
 */
class Cart
{
    /**
     * @var array<int, array{product: Product, qty: int}> товары в корзине
     */
    private array $items = [];

    public function __construct(
        public readonly Customer $customer,
    ) {
    }

    /**
     * Добавляет товар в корзину в количестве $qty штук.
     */
    public function add(Product $p, int $qty): void
    {
        $this->items[] = ['product' => $p, 'qty' => $qty];
    }

    /**
     * Итоговая стоимость всех товаров в корзине.
     */
    public function getTotal(): float
    {
        $total = 0.0;

        foreach ($this->items as $item) {
            $total += $item['product']->price * $item['qty'];
        }

        return $total;
    }
}

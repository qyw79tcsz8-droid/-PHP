<?php

declare(strict_types=1);

namespace Shop\Helpers;

/**
 * Форматирование цены.
 */
class PriceFormatter
{
    /**
     * Возвращает цену в виде «1 250,00 ₽».
     */
    public static function format(float $price): string
    {
        return number_format($price, 2, ',', ' ') . ' ₽';
    }
}

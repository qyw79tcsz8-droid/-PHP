<?php

declare(strict_types=1);

namespace Shop\Models;

/**
 * Товар интернет-магазина.
 */
class Product
{
    public function __construct(
        public string $name,   // название товара
        public float $price,   // цена, руб.
    ) {
    }
}

<?php

declare(strict_types=1);

namespace Shop\Models;

/**
 * Покупатель.
 */
class Customer
{
    public function __construct(
        public string $name,   // имя покупателя
        public string $email,  // электронная почта
    ) {
    }
}

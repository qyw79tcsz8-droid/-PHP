<?php

declare(strict_types=1);

require __DIR__ . '/Employee.php';
require __DIR__ . '/Manager.php';
require __DIR__ . '/Developer.php';

/**
 * Вспомогательная функция: цена в виде «40 000,00 ₽».
 */
function money(float $amount): string
{
    return number_format($amount, 2, ',', ' ') . ' ₽';
}

echo '=== Сотрудники компании ===' . PHP_EOL . PHP_EOL;

// Пункт 8: массив из сотрудников разных типов
$employees = [
    new Employee('Анна Смирнова', 40000, '4510 123456'),
    new Manager('Ирина Ковалёва', 60000, '4511 654321', 3),
    new Developer('Дарья Танаева', 50000, '4512 987654', 'middle'),
    new Developer('Артём Соколов', 50000, '4513 112233', 'senior'),
];

$i = 0;
foreach ($employees as $employee) {
    $i++;
    $type = $employee::class; // то же, что get_class($employee)
    echo "{$i}. {$employee->name} [{$type}]" . PHP_EOL;
    echo "   Зарплата: " . money($employee->getSalary())
        . " | после налога 13%: " . money($employee->getSalaryAfterTax())
        . " | паспорт: " . $employee->getMaskedPassport() . PHP_EOL;
}

// Повышение оклада и работа с историей
echo PHP_EOL . '=== Повышение оклада ===' . PHP_EOL;
$employees[0]->raiseSalary(15);
echo 'Анне Смирновой повышаем оклад на 15%.' . PHP_EOL;
echo 'Новая зарплата: ' . money($employees[0]->getSalary()) . PHP_EOL;
echo 'История изменений: ' . implode('; ', $employees[0]->getSalaryHistory()) . PHP_EOL;

echo 'Пытаемся повысить оклад на 60%:' . PHP_EOL . '   ';
try {
    $employees[0]->raiseSalary(60);
} catch (InvalidArgumentException $e) {
    echo 'Ошибка: ' . $e->getMessage() . PHP_EOL;
}

echo 'Пытаемся повысить оклад на 0%:' . PHP_EOL . '   ';
try {
    $employees[0]->raiseSalary(0);
} catch (InvalidArgumentException $e) {
    echo 'Ошибка: ' . $e->getMessage() . PHP_EOL;
}

// Пункт 7: таблица экспериментов — каждая строка проверена кодом,
// строки с ошибками выполняются внутри try/catch, чтобы скрипт не падал
echo PHP_EOL . '=== Эксперименты (пункт 7) ===' . PHP_EOL;

// 1) Чтение $name снаружи — свойство public
echo '1) Чтение $name снаружи: "' . $employees[0]->name
    . '" — успешно (свойство public)' . PHP_EOL;

// 2) Чтение $baseSalary снаружи — свойство protected
echo '2) Чтение $baseSalary снаружи: ';
try {
    echo $employees[0]->baseSalary;
} catch (Error $e) {
    echo $e->getMessage() . PHP_EOL;
}

// 3) Чтение $baseSalary в Manager — protected доступен наследникам
echo '3) Чтение $baseSalary в Manager: успешно — Manager::getSalary() вернула '
    . $employees[1]->getSalary() . ' (оклад 60000 + 3 × 5000)' . PHP_EOL;

// 4) Чтение $passport в Manager — private недоступен даже наследникам.
//    Строка в Manager.php закомментирована (см. комментарии там), её результат:
echo '4) Чтение $passport в Manager ($this->passport внутри метода):'
    . PHP_EOL . '   Warning: Undefined property: Manager::$passport'
    . ' — значение null, private-свойство' . PHP_EOL
    . '   родителя из наследника даже «не видно», PHP считает его несуществующим.' . PHP_EOL
    . '   А при чтении $passport у объекта Employee (объявляющего класса) снаружи:' . PHP_EOL . '   ';
try {
    $plainEmployee = new Employee('Тест', 10000, '9999 111122');
    echo $plainEmployee->passport;
} catch (Error $e) {
    echo $e->getMessage() . PHP_EOL;
}

// 5) Вызов calculateTax() снаружи — protected-метод
echo '5) Вызов calculateTax() снаружи: ';
try {
    echo $employees[0]->calculateTax(1000);
} catch (Error $e) {
    echo $e->getMessage() . PHP_EOL;
}

// 6) Вызов validatePercent() в Developer — private-метод из области наследника.
//    Строка закомментирована в Developer.php (см. комментарии там),
//    текст ошибки получен при её реальном выполнении:
echo '6) Вызов validatePercent() в Developer: '
    . 'Error: Call to private method Employee::validatePercent() from scope Developer' . PHP_EOL;

// Пункт 6: попытка переопределить final-метод getMaskedPassport() в Developer.
// Код закомментирован в Developer.php — при раскомментировании файл вообще
// перестаёт выполняться, текст ошибки получен при реальном запуске:
echo PHP_EOL . 'Пункт 6: переопределение final-метода getMaskedPassport() в Developer:' . PHP_EOL
    . '   Fatal error: Cannot override final method Employee::getMaskedPassport()'
    . ' in Developer.php (на строке переопределения)' . PHP_EOL;

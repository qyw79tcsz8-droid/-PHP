<?php

declare(strict_types=1);

/**
 * Разработчик — наследник Employee.
 * Зарплата: оклад умножается на коэффициент уровня.
 */
class Developer extends Employee
{
    public const LEVELS = [
        'junior' => 1.0,
        'middle' => 1.5,
        'senior' => 2.0,
    ];

    private string $level;

    public function __construct(string $name, float $baseSalary, string $passport, string $level)
    {
        if (!isset(self::LEVELS[$level])) {
            throw new InvalidArgumentException(
                'Неизвестный уровень «' . $level . '». Допустимо: '
                . implode(', ', array_keys(self::LEVELS))
            );
        }

        parent::__construct($name, $baseSalary, $passport);
        $this->level = $level;
    }

    public function getSalary(): float
    {
        // protected-свойство родителя доступно, умножаем на коэффициент уровня
        return $this->baseSalary * self::LEVELS[$this->level];
    }

    // Эксперимент (пункт 7): вызов private-метода родителя из наследника.
    // Строка проверена кодом и закомментирована:
    // $this->validatePercent(10);
    // Результат: Error: Call to private method Employee::validatePercent() from scope Developer

    // Эксперимент (пункт 6): попытка переопределить final-метод родителя.
    // Код проверен и закомментирован, иначе файл вообще не выполняется:
    // public function getMaskedPassport(): string
    // {
    //     return '**** **0000';
    // }
    // Результат: Fatal error: Cannot override final method Employee::getMaskedPassport()
    // (ошибка возникает сразу при объявлении класса — файл вообще не выполняется)
}

<?php

declare(strict_types=1);

/**
 * Менеджер — наследник Employee.
 * Зарплата: оклад плюс 5 000 ₽ за каждого подчинённого.
 */
class Manager extends Employee
{
    private int $teamSize;

    public function __construct(string $name, float $baseSalary, string $passport, int $teamSize)
    {
        parent::__construct($name, $baseSalary, $passport);
        $this->teamSize = $teamSize;
    }

    public function getSalary(): float
    {
        // $this->baseSalary — protected-свойство родителя, наследнику оно доступно
        return $this->baseSalary + 5000 * $this->teamSize;
    }

    // Эксперимент (пункт 7): чтение private-свойства родителя из наследника.
    // Строка проверена кодом и закомментирована:
    // echo $this->passport;
    // Результат: Warning: Undefined property: Manager::$passport
    // (значение null: private-свойство родителя из наследника даже «не видно»,
    // PHP считает его несуществующим). А вот при чтении $passport у объекта
    // Employee снаружи — Error: Cannot access private property Employee::$passport
}

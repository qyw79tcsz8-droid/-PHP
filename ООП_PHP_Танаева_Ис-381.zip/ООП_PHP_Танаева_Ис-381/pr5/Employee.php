<?php

declare(strict_types=1);

/**
 * Базовый класс сотрудника компании.
 *
 * Демонстрирует выбор модификаторов доступа:
 * - $name           public    — имя открыто всем, оно не секретно;
 * - $baseSalary     protected — оклад нужен наследникам (Manager, Developer)
 *                               для расчёта зарплаты, но снаружи его менять нельзя;
 * - $passport       private   — паспортные данные видны только этому классу;
 * - $salaryHistory  private   — история изменений оклада, доступна только через
 *                               публичный метод getSalaryHistory().
 */
class Employee
{
    public string $name;
    protected float $baseSalary;
    private string $passport;
    private array $salaryHistory = [];

    public function __construct(string $name, float $baseSalary, string $passport)
    {
        $this->name       = $name;
        $this->baseSalary = $baseSalary;
        $this->passport   = $passport;
    }

    /**
     * Итоговая зарплата. В базовом классе равна окладу;
     * наследники переопределяют метод под свои правила.
     */
    public function getSalary(): float
    {
        return $this->baseSalary;
    }

    /**
     * Зарплата после вычета налога (использует protected-метод calculateTax()).
     */
    public function getSalaryAfterTax(): float
    {
        return $this->getSalary() - $this->calculateTax($this->getSalary());
    }

    /**
     * Повышение оклада на процент от 1 до 50.
     * Каждое изменение записывается в историю.
     */
    public function raiseSalary(float $percent): void
    {
        $this->validatePercent($percent);

        $old = $this->baseSalary;
        $this->baseSalary += $this->baseSalary * $percent / 100;

        $this->salaryHistory[] = sprintf(
            '%s → %s (+%.0f%%)',
            number_format($old, 2, ',', ' '),
            number_format($this->baseSalary, 2, ',', ' '),
            $percent
        );
    }

    /**
     * Паспортные данные в замаскированном виде: «**** **3456».
     * Метод объявлен final — переопределять его в наследниках запрещено.
     */
    final public function getMaskedPassport(): string
    {
        return '**** **' . substr($this->passport, -4);
    }

    /**
     * История изменений оклада.
     *
     * @return string[]
     */
    public function getSalaryHistory(): array
    {
        return $this->salaryHistory;
    }

    /**
     * Расчёт налога (13%). Protected: метод нужен классу и наследникам,
     * но внешнему коду он не нужен — снаружи его вызвать нельзя.
     */
    protected function calculateTax(float $amount): float
    {
        return $amount * 0.13;
    }

    /**
     * Проверка процента повышения. Private: используется только внутри
     * этого класса, наследникам она не нужна.
     */
    private function validatePercent(float $p): void
    {
        if ($p < 1 || $p > 50) {
            throw new InvalidArgumentException(
                'Процент повышения должен быть от 1 до 50, получено: ' . $p
            );
        }
    }
}

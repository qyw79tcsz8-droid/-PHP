<?php

declare(strict_types=1);

require __DIR__ . '/QueryBuilder.php';

echo '=== Конструктор SQL-запросов ===' . PHP_EOL . PHP_EOL;

// Запрос 1: полный вариант — select, два where, orderBy, limit.
// Объект выводится через echo — работает магический метод __toString()
echo 'Запрос 1 (цепочка вызовов, вывод через echo):' . PHP_EOL;
echo QueryBuilder::table('users')
    ->select('id', 'name', 'email')
    ->where('age', '>=', 18)
    ->where('city', '=', 'Москва')
    ->orderBy('name')
    ->limit(10);
echo PHP_EOL . PHP_EOL;

// Запрос 2: без select() — выбираются все поля (*), два условия через AND
echo 'Запрос 2 (без select, два условия AND):' . PHP_EOL;
echo QueryBuilder::table('products')
    ->where('price', '>', 1000)
    ->where('stock', '>', 0)
    ->orderBy('price', 'DESC')
    ->toSql(); // тот же результат, что и __toString()
echo PHP_EOL . PHP_EOL;

// Запрос 3: оператор LIKE со строкой-шаблоном
echo 'Запрос 3 (LIKE):' . PHP_EOL;
echo QueryBuilder::table('products')
    ->select('title', 'price')
    ->where('title', 'LIKE', '%iPhone%')
    ->limit(5)
    ->toSql();
echo PHP_EOL . PHP_EOL;

// Запрос 4: строковое значение с кавычкой — проверяем экранирование в quote()
echo 'Запрос 4 (строка с кавычкой — экранирование):' . PHP_EOL;
echo QueryBuilder::table('books')
    ->select('id', 'title')
    ->where('title', 'LIKE', "%О'Рейли%")
    ->orderBy('title', 'desc') // регистр направления не важен — приводится к верхнему
    ->toSql();
echo PHP_EOL . PHP_EOL;

// Запрос 5 (дополнительно, на отлично): «динамические» условия через __call()
echo 'Запрос 5 (дополнительно: динамические условия whereCity(), whereStatus()):' . PHP_EOL;
echo QueryBuilder::table('orders')
    ->select('id', 'customer_name', 'total')
    ->whereCity('Москва')
    ->whereStatus('новый')
    ->orderBy('created_at', 'DESC')
    ->limit(20)
    ->toSql();
echo PHP_EOL . PHP_EOL;

// Пункт 6: проверки аргументов — перехватываем исключения через try/catch
echo '=== Проверка исключений (try/catch) ===' . PHP_EOL;

echo '1) Неверный оператор в where():' . PHP_EOL . '   ';
try {
    QueryBuilder::table('users')->where('age', '~', 18);
} catch (InvalidArgumentException $e) {
    echo $e->getMessage() . PHP_EOL;
}

echo '2) Неверное направление сортировки:' . PHP_EOL . '   ';
try {
    QueryBuilder::table('users')->orderBy('name', 'ASCENDING');
} catch (InvalidArgumentException $e) {
    echo $e->getMessage() . PHP_EOL;
}

echo '3) limit(0):' . PHP_EOL . '   ';
try {
    QueryBuilder::table('users')->limit(0);
} catch (InvalidArgumentException $e) {
    echo $e->getMessage() . PHP_EOL;
}

echo '4) Дополнительно: вызов метода, не начинающегося с where ->sortAll():' . PHP_EOL . '   ';
try {
    QueryBuilder::table('users')->sortAll();
} catch (BadMethodCallException $e) {
    echo $e->getMessage() . PHP_EOL;
}

<?php

declare(strict_types=1);

/**
 * Конструктор SQL-запросов (SELECT).
 *
 * Запрос не выполняется — класс только собирает текст запроса
 * из частей, добавленных через цепочку вызовов.
 *
 * Пример:
 *   QueryBuilder::table('users')
 *       ->select('id', 'name')
 *       ->where('age', '>=', 18)
 *       ->orderBy('name')
 *       ->limit(10);
 */
class QueryBuilder
{
    /** Допустимые операторы для условий WHERE */
    private const OPERATORS = ['=', '!=', '>', '<', '>=', '<=', 'LIKE'];

    /** Допустимые направления сортировки */
    private const DIRECTIONS = ['ASC', 'DESC'];

    private string $table;

    /** @var string[] список полей после SELECT */
    private array $columns = [];

    /** @var string[] условия WHERE (объединяются через AND) */
    private array $conditions = [];

    private string $orderBy = '';

    private ?int $limit = null;

    public function __construct(string $table)
    {
        $this->table = $table;
    }

    /**
     * Статический метод-фабрика: создаёт объект и запоминает таблицу.
     */
    public static function table(string $name): static
    {
        return new static($name);
    }

    /**
     * Список полей выборки. Без вызова select() выбирается * (все поля).
     */
    public function select(string ...$columns): static
    {
        $this->columns = $columns;

        return $this;
    }

    /**
     * Добавляет условие WHERE. Несколько вызовов объединяются через AND.
     */
    public function where(string $column, string $operator, string|int $value): static
    {
        if (!in_array($operator, self::OPERATORS, true)) {
            throw new InvalidArgumentException(
                'Неизвестный оператор «' . $operator . '». Допустимо: '
                . implode(', ', self::OPERATORS)
            );
        }

        $this->conditions[] = "{$column} {$operator} " . $this->quote($value);

        return $this;
    }

    /**
     * Сортировка результата, направление — только ASC или DESC.
     */
    public function orderBy(string $column, string $direction = 'ASC'): static
    {
        $direction = mb_strtoupper($direction);

        if (!in_array($direction, self::DIRECTIONS, true)) {
            throw new InvalidArgumentException(
                'Направление сортировки должно быть ASC или DESC, получено: ' . $direction
            );
        }

        $this->orderBy = "{$column} {$direction}";

        return $this;
    }

    /**
     * Ограничение количества строк. LIMIT должен быть больше 0.
     */
    public function limit(int $count): static
    {
        if ($count <= 0) {
            throw new InvalidArgumentException(
                'LIMIT должен быть больше 0, получено: ' . $count
            );
        }

        $this->limit = $count;

        return $this;
    }

    /**
     * Собирает итоговый SQL-запрос из сохранённых частей.
     */
    public function toSql(): string
    {
        $sql = 'SELECT ' . ($this->columns === [] ? '*' : implode(', ', $this->columns));
        $sql .= " FROM {$this->table}";

        if ($this->conditions !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $this->conditions);
        }

        if ($this->orderBy !== '') {
            $sql .= " ORDER BY {$this->orderBy}";
        }

        if ($this->limit !== null) {
            $sql .= " LIMIT {$this->limit}";
        }

        return $sql;
    }

    /**
     * Магический метод: позволяет вывести объект через echo.
     */
    public function __toString(): string
    {
        return $this->toSql();
    }

    /**
     * Дополнительно (на отлично): «динамические» условия вида ->whereCity('Москва'),
     * которые превращаются в ->where('city', '=', 'Москва').
     */
    public function __call(string $name, array $arguments): static
    {
        if (str_starts_with($name, 'where')) {
            $column = lcfirst(substr($name, strlen('where')));

            return $this->where($column, '=', $arguments[0]);
        }

        throw new BadMethodCallException("Метод {$name} не существует в QueryBuilder");
    }

    /**
     * Приватный вспомогательный метод: строки берёт в одинарные кавычки
     * (экранируя внутренние кавычки удвоением), числа оставляет как есть.
     */
    private function quote(string|int $value): string
    {
        if (is_int($value)) {
            return (string) $value;
        }

        return "'" . str_replace("'", "''", $value) . "'";
    }
}
